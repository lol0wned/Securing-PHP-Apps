<?php 
function isLoggedIn(){
	return $_SESSION['isLoggedIn'];
}
?>