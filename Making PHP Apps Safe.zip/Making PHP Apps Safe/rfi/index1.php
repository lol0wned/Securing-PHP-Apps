<html>
	<body>
		<?php include $_GET['theme'].'.php'; ?>
		<h1>Hello Zomato!</h1>
	</body>
</html>