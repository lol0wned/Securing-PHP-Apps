<html>
	<body>
		<?php include $_GET['theme']; ?>
		<h1>Hello Zomato!</h1>
	</body>
</html>