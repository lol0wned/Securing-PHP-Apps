<?php
$name = $_REQUEST['name'];
$about = $_REQUEST['about'];
$username = $_REQUEST['username'];
// update user info
?>