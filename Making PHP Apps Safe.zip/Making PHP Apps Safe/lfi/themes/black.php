<style type="text/css">
body {
    background-color: black;
}
</style>