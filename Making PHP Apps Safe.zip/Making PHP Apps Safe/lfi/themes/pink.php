<style type="text/css">
body {
    background-color: pink;
}
</style>