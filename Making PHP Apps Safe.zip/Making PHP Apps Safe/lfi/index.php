<html>
	<body>
		<?php include 'themes/'.$_GET['theme']; ?>
		<h1>Hello Zomato!</h1>
	</body>
</html>